<?php
header('Content-Type: text/html; charset=utf-8');
header('Location: wiki.php?a=view&title=SyntaxGuide');
exit;
?>
