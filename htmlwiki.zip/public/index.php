<?php
// Unify entrypoint: redirect to wiki front route
header('Location: wiki.php?a=front');
exit;
?>
