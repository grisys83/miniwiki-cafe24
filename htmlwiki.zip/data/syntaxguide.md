# 문법 안내 (Markdown + 위키 링크)

이 위키는 “마크다운 위키위키” 모드를 사용합니다. 블록/인라인은 Markdown 문법을 따르고, 링크는 위키 문법인 `[[...]]`를 사용합니다.

## 헤딩 (Headings)
# H1 제목
## H2 제목
### H3 제목

## 강조 (Emphasis)
- 기울임: *italic*
- 굵게: **bold**
- 굵게+기울임: ***bold italic*** 또는 **_bold italic_**

## 줄바꿈
- 한 문단 안에서 한 줄 개행은 `<br />`로 렌더링됩니다.
- 문단 분리는 빈 줄(공백 라인)로 합니다.

## 링크 (Links)
- 내부 링크(페이지 이동):
  - `[[FrontPage]]`
  - `[[Home|홈으로]]`
- 외부 링크:
  - `[[OpenAI|https://openai.com]]`
  - 자동 링크 허용 시: https://example.com
- 주의: Markdown의 `[label](url)` 형식은 내부 링크로 처리되지 않습니다. 내부 링크는 반드시 `[[...]]`를 쓰세요.

## 이미지 (Images)
- Markdown 이미지 문법을 사용합니다.

```markdown
![Placeholder](https://via.placeholder.com/120)
```

## 목록 (Lists)
- 순서 없는 목록:
  - `- 항목`
  - `+ 항목`
  - `* 항목`
- 들여쓰기(스페이스 2칸)로 중첩합니다.
- 순서 있는 목록: `1.`, `2.` …

예)

```
- 첫째
- 둘째
  - 둘째-하위
1. 하나
2. 둘
```

## 인용 (Blockquote)
`>` 로 시작하는 줄을 사용합니다.

```
> 인용문 1줄
> 인용문 2줄
```

## 코드 (Code)
- 인라인 코드: `` `inline()` ``
- 펜스드 코드 블록:

```
```
function hello() {
  return 'world';
}
```
```

## 표 (Tables)
Markdown 표 문법을 지원합니다. 구분선에 콜론으로 정렬을 지정할 수 있습니다.

```
| 열 A | 열 B | 열 C |
| :--- | :---: | ---: |
| left | center | right |
| 1 | 2 | 3 |
```

## 리다이렉트 (Redirect)
페이지를 새 제목으로 넘기려면 본문 맨 위에 다음 한 줄을 넣습니다.

```
#REDIRECT [[새제목]]
```

## 내부 링크 예시
- 자기 참조: [[SyntaxGuide]]
- FrontPage로 이동: [[FrontPage]]
- 라벨 지정: [[Home|홈으로]]

---

도움이 필요하면 FrontPage를 참고하거나 새 페이지를 만들어보세요. 새 페이지는 상단의 New를 눌러 제목을 입력하면 됩니다.
