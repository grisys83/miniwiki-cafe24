<?php
// PHP 4–compatible minimal wiki parser

if (!function_exists('wiki_parse')) {

    function wiki_parse($text, $options = array()) {
        // Options (all optional)
        // - 'auto_link' => bool (default false)
        // - 'rel_nofollow' => bool (default true)
        // - 'hard_wrap' => bool (default true) // single newline inside paragraphs -> <br />
        // - 'internal_links' => bool (default true) // [[Page]] or [[Page|Label]]
        // - 'internal_base' => string (default 'wiki.php') // link target script
        // - 'internal_param' => string (default 'title') // query parameter for page title

        if (!is_array($options)) { $options = array(); }
        $auto_link     = isset($options['auto_link']) ? (bool)$options['auto_link'] : false;
        $rel_nofollow  = !isset($options['rel_nofollow']) || (bool)$options['rel_nofollow'];
        $hard_wrap     = !isset($options['hard_wrap']) || (bool)$options['hard_wrap'];
        $internal_on   = !isset($options['internal_links']) || (bool)$options['internal_links'];
        $internal_base = isset($options['internal_base']) ? (string)$options['internal_base'] : 'wiki.php';
        $internal_param = isset($options['internal_param']) ? (string)$options['internal_param'] : 'title';

        $text = str_replace("\r\n", "\n", $text);
        $text = str_replace("\r", "\n", $text);

        $lines = explode("\n", $text);
        $out = '';

        $in_pre = false;
        $pre_buffer = '';

        $in_blockquote = false;

        // Table state (MediaWiki-like syntax)
        $in_table = false;
        $in_table_row = false;

        $list_stack = array(); // values: 'ul' or 'ol'
        $li_open = array();    // parallel to list_stack: bool per level

        $para_open = false;

        $total = count($lines);
        for ($i = 0; $i < $total; $i++) {
            $line = $lines[$i];
            $trim = trim($line);

            // Handle code blocks {{{ }}} or ``` ```
            if ($in_pre) {
                if ($trim === '}}}' || $trim === '```') {
                    // Close code block
                    $out .= '<pre>' . wiki_escape_html($pre_buffer) . "</pre>\n";
                    $in_pre = false;
                    $pre_buffer = '';
                    continue;
                } else {
                    $pre_buffer .= $line . "\n";
                    continue;
                }
            }

            // Table start: {|
            if (!$in_pre && !$in_table && $trim !== '' && preg_match('/^\s*\{\|/', $line)) {
                wiki_close_paragraph($out, $para_open);
                wiki_close_lists_all($out, $list_stack, $li_open);
                if ($in_blockquote) { $out .= "</blockquote>\n"; $in_blockquote = false; }
                $out .= "<table>\n";
                $in_table = true;
                $in_table_row = false;
                continue;
            }

            // Inside table handling
            if ($in_table) {
                // End table: |}
                if ($trim !== '' && preg_match('/^\s*\|\}\s*$/', $line)) {
                    if ($in_table_row) { $out .= "</tr>\n"; $in_table_row = false; }
                    $out .= "</table>\n";
                    $in_table = false;
                    continue;
                }

                // Row separator: |-
                if ($trim !== '' && preg_match('/^\s*\|-/', $line)) {
                    if ($in_table_row) { $out .= "</tr>\n"; $in_table_row = false; }
                    // Do not open a row yet; next cell line will open it
                    continue;
                }

                // Caption: |+ [attrs|] text
                if ($trim !== '' && preg_match('/^\s*\|\+\s*(.*)$/', $line, $mcap)) {
                    $cap = trim($mcap[1]);
                    // If attributes present like "attr| text", take the part after the first '|'
                    $posBar = strpos($cap, '|');
                    if ($posBar !== false) { $cap = trim(substr($cap, $posBar + 1)); }
                    $out .= '<caption>' . wiki_inline($cap, $options) . "</caption>\n";
                    continue;
                }

                // Header cells: ! a !! b !! c
                if ($trim !== '' && preg_match('/^\s*!\s*(.*)$/', $line, $mh)) {
                    $cells_line = $mh[1];
                    // Split on '!!'
                    $cells = preg_split('/\s*!!\s*/', $cells_line);
                    if (!$in_table_row) { $out .= "<tr>\n"; $in_table_row = true; }
                    for ($ci = 0; $ci < count($cells); $ci++) {
                        $cell = trim($cells[$ci]);
                        // Handle optional attrs like "attr| text" by taking text after first '|'
                        $p = strpos($cell, '|');
                        if ($p !== false) { $cell = trim(substr($cell, $p + 1)); }
                        $out .= '<th>' . wiki_inline($cell, $options) . '</th>';
                    }
                    // Close row after header line for simplicity
                    if ($in_table_row) { $out .= "\n</tr>\n"; $in_table_row = false; }
                    continue;
                }

                // Data cells: | a || b || c
                if ($trim !== '' && preg_match('/^\s*\|\s*(.*)$/', $line, $md)) {
                    $cells_line = $md[1];
                    $cells = preg_split('/\s*\|\|\s*/', $cells_line);
                    if (!$in_table_row) { $out .= "<tr>\n"; $in_table_row = true; }
                    for ($ci = 0; $ci < count($cells); $ci++) {
                        $cell = trim($cells[$ci]);
                        $p = strpos($cell, '|');
                        if ($p !== false) { $cell = trim(substr($cell, $p + 1)); }
                        $out .= '<td>' . wiki_inline($cell, $options) . '</td>';
                    }
                    // Close row after data line for simplicity
                    if ($in_table_row) { $out .= "\n</tr>\n"; $in_table_row = false; }
                    continue;
                }

                // Blank or unrecognized lines inside table: ignore
                continue;
            }

            // Start of code block
            if ($trim === '{{{' || $trim === '```') {
                wiki_close_paragraph($out, $para_open);
                wiki_close_lists_all($out, $list_stack, $li_open);
                if ($in_blockquote) { $out .= "</blockquote>\n"; $in_blockquote = false; }
                $in_pre = true;
                $pre_buffer = '';
                continue;
            }

            // Horizontal rule
            if ($trim !== '' && preg_match('/^-{4,}$/', $trim)) {
                wiki_close_paragraph($out, $para_open);
                wiki_close_lists_all($out, $list_stack, $li_open);
                if ($in_blockquote) { $out .= "</blockquote>\n"; $in_blockquote = false; }
                $out .= "<hr />\n";
                continue;
            }

            // Headings: = H1 = .. ====== H6 ======
            if ($trim !== '' && preg_match('/^\s{0,3}(=+)\s*(.*?)\s*\1\s*$/', $line, $m)) {
                $level = strlen($m[1]);
                if ($level > 6) { $level = 6; }
                wiki_close_paragraph($out, $para_open);
                wiki_close_lists_all($out, $list_stack, $li_open);
                if ($in_blockquote) { $out .= "</blockquote>\n"; $in_blockquote = false; }
                $content = wiki_inline(trim($m[2]), $options);
                $out .= '<h' . $level . '>' . $content . '</h' . $level . ">\n";
                continue;
            }

            // Blockquote lines starting with '>'
            if ($trim !== '' && strlen($trim) > 0 && $trim{0} === '>') {
                // Enter blockquote if not already
                wiki_close_paragraph($out, $para_open);
                wiki_close_lists_all($out, $list_stack, $li_open);
                if (!$in_blockquote) {
                    $out .= "<blockquote>\n";
                    $in_blockquote = true;
                }
                // Remove leading > characters and one optional space
                $txt = preg_replace('/^>+\s?/', '', $line);
                $out .= wiki_inline(trim($txt), $options) . "<br />\n";
                // Do not continue; allow next line to determine closing
                continue;
            } else {
                if ($in_blockquote && $trim === '') {
                    $out .= "</blockquote>\n";
                    $in_blockquote = false;
                } else if ($in_blockquote && $trim !== '' && $trim{0} !== '>') {
                    $out .= "</blockquote>\n";
                    $in_blockquote = false;
                }
            }

            // Lists: lines starting with one or more '*' or '#'
            if ($trim !== '' && preg_match('/^([*#]+)\s*(.*)$/', $line, $m)) {
                $markers = $m[1];
                $content_raw = $m[2];

                // Desired types for this line depth
                $desired = array();
                $mlen = strlen($markers);
                for ($k = 0; $k < $mlen; $k++) {
                    $ch = $markers{$k};
                    $desired[] = ($ch === '*') ? 'ul' : 'ol';
                }

                // Adjust containers to match desired prefix
                $common = wiki_list_common_prefix($list_stack, $desired);
                // Close deeper levels
                for ($lvl = count($list_stack) - 1; $lvl >= $common; $lvl--) {
                    if (isset($li_open[$lvl]) && $li_open[$lvl]) {
                        $out .= "</li>\n";
                        $li_open[$lvl] = false;
                    }
                    $out .= '</' . $list_stack[$lvl] . ">\n";
                    array_pop($list_stack);
                    array_pop($li_open);
                }
                // Open new containers
                for ($lvl = $common; $lvl < count($desired); $lvl++) {
                    $t = $desired[$lvl];
                    $out .= '<' . $t . ">\n";
                    $list_stack[] = $t;
                    $li_open[] = false;
                }

                // Open a new list item at the deepest level
                $deep = count($desired) - 1;
                if (!isset($li_open[$deep]) || !$li_open[$deep]) {
                    $out .= '<li>';
                    $li_open[$deep] = true;
                } else {
                    // If somehow already open, close and reopen
                    $out .= "</li>\n<li>";
                }

                $out .= wiki_inline(trim($content_raw), $options);

                // Peek ahead to decide whether to close this <li>
                $next_line = ($i + 1 < $total) ? $lines[$i + 1] : '';
                $next_trim = trim($next_line);
                $close_li_now = true;
                if ($next_trim !== '' && preg_match('/^([*#]+)\s*(.*)$/', $next_line, $nm)) {
                    $next_markers = $nm[1];
                    $next_desired = array();
                    $nmlen = strlen($next_markers);
                    for ($k = 0; $k < $nmlen; $k++) {
                        $ch = $next_markers{$k};
                        $next_desired[] = ($ch === '*') ? 'ul' : 'ol';
                    }
                    if (count($next_desired) > count($desired)) {
                        // Next is deeper => keep <li> open to nest
                        $close_li_now = false;
                    }
                }
                if ($close_li_now) {
                    $out .= "</li>\n";
                    $li_open[$deep] = false;
                }
                // Keep lists open; continue to next line
                continue;
            } else {
                // If we were in lists and current line is not a list, close all
                if (count($list_stack)) {
                    wiki_close_lists_all($out, $list_stack, $li_open);
                }
            }

            // Blank line => close paragraph if open
            if ($trim === '') {
                wiki_close_paragraph($out, $para_open);
                continue;
            }

            // Normal paragraph text
            if (!$para_open) {
                $out .= '<p>';
                $para_open = true;
            } else {
                // New line within paragraph
                $out .= $hard_wrap ? "<br />\n" : "\n";
            }
            $out .= wiki_inline($trim, $options);
        }

        // Close any remaining open blocks
        if ($in_pre) {
            $out .= '<pre>' . wiki_escape_html($pre_buffer) . "</pre>\n";
            $in_pre = false;
        }
        if ($in_blockquote) {
            $out .= "</blockquote>\n";
        }
        if (count($list_stack)) {
            wiki_close_lists_all($out, $list_stack, $li_open);
        }
        // Close open table at EOF
        if ($in_table) {
            if ($in_table_row) { $out .= "</tr>\n"; $in_table_row = false; }
            $out .= "</table>\n";
            $in_table = false;
        }
        wiki_close_paragraph($out, $para_open);

        return $out;
    }

    function wiki_close_paragraph(&$out, &$para_open) {
        if ($para_open) { $out .= "</p>\n"; $para_open = false; }
    }

    function wiki_close_lists_all(&$out, &$list_stack, &$li_open) {
        for ($lvl = count($list_stack) - 1; $lvl >= 0; $lvl--) {
            if (isset($li_open[$lvl]) && $li_open[$lvl]) {
                $out .= "</li>\n";
                $li_open[$lvl] = false;
            }
            $out .= '</' . $list_stack[$lvl] . ">\n";
        }
        $list_stack = array();
        $li_open = array();
    }

    function wiki_list_common_prefix($a, $b) {
        $n = min(count($a), count($b));
        $i = 0;
        while ($i < $n && $a[$i] === $b[$i]) { $i++; }
        return $i;
    }

    function wiki_escape_html($s) {
        return htmlspecialchars($s, ENT_QUOTES);
    }

    function wiki_sanitize_url($url) {
        $url = trim($url);
        // Decode HTML entities if any present from user text (defense-in-depth)
        $url = html_entity_decode($url);
        // Allow only http/https
        if (preg_match('/^(https?:)\/\//i', $url)) {
            return $url;
        }
        return '';
    }

    function wiki_attr($s) {
        // Escape for attribute context
        $s = str_replace("\r", '', $s);
        $s = str_replace("\n", ' ', $s);
        return htmlspecialchars($s, ENT_QUOTES);
    }

    function wiki_inline($text, $options) {
        // Process inline code first: {{{code}}} and `code`
        // Use callbacks to escape internal contents
        if (!function_exists('wiki_cb_inline_code_braces')) {
            function wiki_cb_inline_code_braces($m) {
                return '<code>' . wiki_escape_html($m[1]) . '</code>';
            }
        }
        if (!function_exists('wiki_cb_inline_code_backticks')) {
            function wiki_cb_inline_code_backticks($m) {
                return '<code>' . wiki_escape_html($m[1]) . '</code>';
            }
        }

        $text = preg_replace_callback('/\{\{\{\s*([^\n]+?)\s*\}\}\}/', 'wiki_cb_inline_code_braces', $text);
        $text = preg_replace_callback('/`([^`\n]+)`/', 'wiki_cb_inline_code_backticks', $text);

        // Images: [[Image:URL|alt]] or [[img:URL|alt]] or [[File:URL|alt]]
        if (!function_exists('wiki_cb_image')) {
            function wiki_cb_image($m) {
                $url = wiki_sanitize_url($m[2]);
                $alt = isset($m[3]) ? trim($m[3]) : '';
                if ($url === '') { return wiki_escape_html($m[0]); }
                return '<img src="' . wiki_attr($url) . '" alt="' . wiki_attr($alt) . '" />';
            }
        }
        $text = preg_replace_callback('/\[\[(?:Image|File|img):([^\]|]+)(?:\|([^\]]*))?\]\]/i',
            function_exists('wiki_cb_image') ? 'wiki_cb_image' : 'wiki_cb_image', $text);

        // Links: [[label|url]] or [[url|label]]
        if (!function_exists('wiki_cb_bracket_link')) {
            function wiki_cb_bracket_link($m) {
                $a = trim($m[1]);
                $b = trim($m[2]);
                $label = '';
                $url = '';
                if (preg_match('/^https?:\/\//i', $a)) { $url = $a; $label = $b; }
                else if (preg_match('/^https?:\/\//i', $b)) { $url = $b; $label = $a; }
                else { return wiki_escape_html($m[0]); }
                $url = wiki_sanitize_url($url);
                if ($url === '') { return wiki_escape_html($m[0]); }
                $attrs = ' href="' . wiki_attr($url) . '"';
                $rel_nofollow = !isset($GLOBALS['__wiki_rel_nofollow']) || $GLOBALS['__wiki_rel_nofollow'];
                if ($rel_nofollow) { $attrs .= ' rel="nofollow"'; }
                return '<a' . $attrs . '>' . wiki_escape_html($label) . '</a>';
            }
        }
        // Store rel_nofollow in a global so callbacks can see it (PHP4 limitation)
        $GLOBALS['__wiki_rel_nofollow'] = isset($options['rel_nofollow']) ? (bool)$options['rel_nofollow'] : true;
        $text = preg_replace_callback('/\[\[([^\]|]+)\|([^\]]+)\]\]/',
            function_exists('wiki_cb_bracket_link') ? 'wiki_cb_bracket_link' : 'wiki_cb_bracket_link', $text);

        // Internal links: [[Page]] or [[Page|Label]]
        if (!function_exists('wiki_build_internal_href')) {
            function wiki_build_internal_href($page) {
                $base = isset($GLOBALS['__wiki_internal_base']) ? $GLOBALS['__wiki_internal_base'] : 'wiki.php';
                $param = isset($GLOBALS['__wiki_internal_param']) ? $GLOBALS['__wiki_internal_param'] : 'title';
                $href = $base;
                // Append query parameter
                $sep = (strpos($href, '?') !== false) ? '&' : '?';
                $href .= $sep . $param . '=' . rawurlencode(trim($page));
                return $href;
            }
        }
        if (!function_exists('wiki_cb_internal_link')) {
            function wiki_cb_internal_link($m) {
                if (!isset($GLOBALS['__wiki_internal_on']) || !$GLOBALS['__wiki_internal_on']) {
                    return wiki_escape_html($m[0]);
                }
                $page = trim($m[1]);
                $label = isset($m[2]) ? trim($m[2]) : $page;
                // If looks like external link, do not treat as internal
                if (preg_match('/^https?:\/\//i', $page)) { return wiki_escape_html($m[0]); }
                $href = wiki_build_internal_href($page);
                return '<a href="' . wiki_attr($href) . '">' . wiki_escape_html($label) . '</a>';
            }
        }
        $GLOBALS['__wiki_internal_on'] = isset($options['internal_links']) ? (bool)$options['internal_links'] : true;
        $GLOBALS['__wiki_internal_base'] = isset($options['internal_base']) ? $options['internal_base'] : 'wiki.php';
        $GLOBALS['__wiki_internal_param'] = isset($options['internal_param']) ? $options['internal_param'] : 'title';
        $text = preg_replace_callback('/\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/',
            function_exists('wiki_cb_internal_link') ? 'wiki_cb_internal_link' : 'wiki_cb_internal_link', $text);

        // Links: [url label]
        if (!function_exists('wiki_cb_square_link')) {
            function wiki_cb_square_link($m) {
                $url = wiki_sanitize_url($m[1]);
                if ($url === '') { return wiki_escape_html($m[0]); }
                $label = trim($m[2]);
                $attrs = ' href="' . wiki_attr($url) . '"';
                $rel_nofollow = !isset($GLOBALS['__wiki_rel_nofollow']) || $GLOBALS['__wiki_rel_nofollow'];
                if ($rel_nofollow) { $attrs .= ' rel="nofollow"'; }
                return '<a' . $attrs . '>' . wiki_escape_html($label) . '</a>';
            }
        }
        $text = preg_replace_callback('/\[(https?:\/\/[^\s\]]+)\s+([^\]]+)\]/',
            function_exists('wiki_cb_square_link') ? 'wiki_cb_square_link' : 'wiki_cb_square_link', $text);

        // Bold+Italic first, then Bold, then Italic (MediaWiki style tokens)
        // '''''text'''''
        $text = preg_replace('/\'\'\'\'\'(.+?)\'\'\'\'\'/s', '<strong><em>$1</em></strong>', $text);
        // '''text'''
        $text = preg_replace('/\'\'\'(.+?)\'\'\'/s', '<strong>$1</strong>', $text);
        // ''text''
        $text = preg_replace('/\'\'(.+?)\'\'/s', '<em>$1</em>', $text);

        // Auto-link bare URLs if enabled (best-effort, avoid inside existing tags)
        if (isset($options['auto_link']) && $options['auto_link']) {
            if (!function_exists('wiki_cb_autolink')) {
                function wiki_cb_autolink($m) {
                    $lead = isset($m[1]) ? $m[1] : '';
                    $url = wiki_sanitize_url($m[2]);
                    if ($url === '') { return $m[0]; }
                    $attrs = ' href="' . wiki_attr($url) . '"';
                    $rel_nofollow = !isset($GLOBALS['__wiki_rel_nofollow']) || $GLOBALS['__wiki_rel_nofollow'];
                    if ($rel_nofollow) { $attrs .= ' rel="nofollow"'; }
                    return $lead . '<a' . $attrs . '>' . wiki_escape_html($url) . '</a>';
                }
            }
            // Match URLs not immediately after '=' or '"' to reduce false positives inside attributes
            $text = preg_replace_callback('/(^|[^=\"\'])(https?:\/\/[\w\-\.\~\/%\?#@!$&\'"()*+,;=:\[\]]+)/',
                function_exists('wiki_cb_autolink') ? 'wiki_cb_autolink' : 'wiki_cb_autolink', $text);
        }

        // Finally, escape remaining text outside of our inserted tags
        // Caution: We already inserted HTML tags above; the rest must be escaped without touching tags.
        // Strategy: Split on tags and escape only text segments.
        $parts = preg_split('/(<[^>]+>)/', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
        $rebuilt = '';
        for ($i = 0; $i < count($parts); $i++) {
            $part = $parts[$i];
            if ($part === '') { continue; }
            if ($part{0} === '<') { $rebuilt .= $part; }
            else { $rebuilt .= wiki_escape_html($part); }
        }
        return $rebuilt;
    }
}

// Markdown blocks + wiki-style links renderer
if (!function_exists('md_parse')) {
    function md_parse($text, $options = array()) {
        if (!is_array($options)) { $options = array(); }
        $auto_link     = isset($options['auto_link']) ? (bool)$options['auto_link'] : false;
        $rel_nofollow  = !isset($options['rel_nofollow']) || (bool)$options['rel_nofollow'];
        $hard_wrap     = !isset($options['hard_wrap']) || (bool)$options['hard_wrap'];
        $internal_on   = !isset($options['internal_links']) || (bool)$options['internal_links'];
        $internal_base = isset($options['internal_base']) ? (string)$options['internal_base'] : 'wiki.php';
        $internal_param = isset($options['internal_param']) ? (string)$options['internal_param'] : 'title';

        $text = str_replace("\r\n", "\n", $text);
        $text = str_replace("\r", "\n", $text);

        $lines = explode("\n", $text);
        $out = '';
        $para_open = false;
        $in_pre = false;
        $pre_buffer = '';
        $in_blockquote = false;
        $list_stack = array(); // 'ul' or 'ol'
        $li_open = array();

        $total = count($lines);
        for ($i = 0; $i < $total; $i++) {
            $line = $lines[$i];
            $trim = rtrim($line);

            if ($in_pre) {
                if (trim($line) === '```') {
                    $out .= '<pre>' . wiki_escape_html($pre_buffer) . "</pre>\n";
                    $in_pre = false; $pre_buffer = '';
                    continue;
                } else {
                    $pre_buffer .= $line . "\n";
                    continue;
                }
            }

            // Fenced code
            if (trim($line) === '```') {
                md_close_paragraph($out, $para_open);
                md_close_lists_all($out, $list_stack, $li_open);
                if ($in_blockquote) { $out .= "</blockquote>\n"; $in_blockquote = false; }
                $in_pre = true; $pre_buffer = '';
                continue;
            }

            // Markdown table block
            if (md_maybe_table_row($line)) {
                // Need a delimiter line next
                $next = ($i + 1 < $total) ? $lines[$i + 1] : '';
                $aligns = array();
                if (md_is_table_delim_line($next, $aligns)) {
                    md_close_paragraph($out, $para_open);
                    md_close_lists_all($out, $list_stack, $li_open);
                    if ($in_blockquote) { $out .= "</blockquote>\n"; $in_blockquote = false; }

                    $headers = md_table_cells($line);
                    // Normalize aligns length
                    while (count($aligns) < count($headers)) { $aligns[] = ''; }

                    $out .= "<table>\n<thead>\n<tr>";
                    for ($ci = 0; $ci < count($headers); $ci++) {
                        $cell = trim($headers[$ci]);
                        $style = md_align_style(isset($aligns[$ci]) ? $aligns[$ci] : '');
                        $out .= '<th' . ($style !== '' ? ' style="' . $style . '"' : '') . '>' . md_inline($cell, $options) . '</th>';
                    }
                    $out .= "</tr>\n</thead>\n<tbody>\n";

                    // Consume delimiter line
                    $i++;
                    // Iterate following table rows
                    while ($i + 1 < $total) {
                        $peek = $lines[$i + 1];
                        if (!md_maybe_table_row($peek)) { break; }
                        $i++;
                        $cells = md_table_cells($peek);
                        $out .= '<tr>';
                        for ($ci = 0; $ci < count($cells); $ci++) {
                            $cell = trim($cells[$ci]);
                            $style = md_align_style(isset($aligns[$ci]) ? $aligns[$ci] : '');
                            $out .= '<td' . ($style !== '' ? ' style="' . $style . '"' : '') . '>' . md_inline($cell, $options) . '</td>';
                        }
                        $out .= "</tr>\n";
                    }
                    $out .= "</tbody>\n</table>\n";
                    continue;
                }
            }

            // Horizontal rule
            if (preg_match('/^\s*([\-*\_])\1\1[\-\*\_]*\s*$/', $line)) {
                md_close_paragraph($out, $para_open);
                md_close_lists_all($out, $list_stack, $li_open);
                if ($in_blockquote) { $out .= "</blockquote>\n"; $in_blockquote = false; }
                $out .= "<hr />\n"; continue;
            }

            // Heading: # .. ######
            if (preg_match('/^\s{0,3}(#{1,6})\s*(.*?)\s*#*\s*$/', $line, $m)) {
                $level = strlen($m[1]); if ($level < 1) $level = 1; if ($level > 6) $level = 6;
                md_close_paragraph($out, $para_open);
                md_close_lists_all($out, $list_stack, $li_open);
                if ($in_blockquote) { $out .= "</blockquote>\n"; $in_blockquote = false; }
                $content = md_inline(trim($m[2]), $options);
                $out .= '<h' . $level . '>' . $content . '</h' . $level . ">\n";
                continue;
            }

            // Blockquote
            if (preg_match('/^\s*>\s?(.*)$/', $line, $mq)) {
                md_close_paragraph($out, $para_open);
                md_close_lists_all($out, $list_stack, $li_open);
                if (!$in_blockquote) { $out .= "<blockquote>\n"; $in_blockquote = true; }
                $out .= md_inline(trim($mq[1]), $options) . "<br />\n";
                continue;
            } else {
                if ($in_blockquote && trim($line) === '') { $out .= "</blockquote>\n"; $in_blockquote = false; }
                else if ($in_blockquote && !preg_match('/^\s*>/', $line)) { $out .= "</blockquote>\n"; $in_blockquote = false; }
            }

            // Lists (UL/OL)
            if (preg_match('/^(\s*)([-+*]|\d+\.)\s+(.*)$/', $line, $ml)) {
                $indent = strlen($ml[1]);
                $marker = $ml[2];
                $content_raw = $ml[3];
                $type = (substr($marker, -1) === '.') ? 'ol' : 'ul';
                $level = (int) floor($indent / 2);

                // Ensure list nesting
                $cur = count($list_stack);
                if ($level < $cur) {
                    for ($lvl = $cur - 1; $lvl >= $level; $lvl--) {
                        if ($li_open[$lvl]) { $out .= "</li>\n"; $li_open[$lvl] = false; }
                        $out .= '</' . $list_stack[$lvl] . ">\n";
                        array_pop($list_stack); array_pop($li_open);
                    }
                } elseif ($level > $cur) {
                    for ($lvl = $cur; $lvl < $level; $lvl++) {
                        $out .= '<ul>' . "\n"; $list_stack[] = 'ul'; $li_open[] = false;
                    }
                }

                // Open list container if type changed
                if (!count($list_stack) || $list_stack[count($list_stack)-1] !== $type) {
                    $out .= '<' . $type . ">\n"; $list_stack[] = $type; $li_open[] = false;
                }

                $deep = count($list_stack) - 1;
                if (!$li_open[$deep]) { $out .= '<li>'; $li_open[$deep] = true; } else { $out .= "</li>\n<li>"; }
                $out .= md_inline(trim($content_raw), $options);

                // Lookahead to close li if next line not deeper indent
                $next = ($i+1<$total) ? $lines[$i+1] : '';
                if (!preg_match('/^(\s*)([-+*]|\d+\.)\s+/', $next)) { $out .= "</li>\n"; $li_open[$deep] = false; }
                continue;
            } else {
                if (count($list_stack)) { md_close_lists_all($out, $list_stack, $li_open); }
            }

            // Blank line ends paragraph
            if (trim($line) === '') { md_close_paragraph($out, $para_open); continue; }

            // Paragraph
            if (!$para_open) { $out .= '<p>'; $para_open = true; }
            else { $out .= $hard_wrap ? "<br />\n" : "\n"; }
            $out .= md_inline(trim($line), $options);
        }

        if ($in_pre) { $out .= '<pre>' . wiki_escape_html($pre_buffer) . "</pre>\n"; }
        if ($in_blockquote) { $out .= "</blockquote>\n"; }
        if (count($list_stack)) { md_close_lists_all($out, $list_stack, $li_open); }
        md_close_paragraph($out, $para_open);
        return $out;
    }

    function md_close_paragraph(&$out, &$para_open) { if ($para_open) { $out .= "</p>\n"; $para_open = false; } }
    function md_close_lists_all(&$out, &$list_stack, &$li_open) {
        for ($lvl = count($list_stack) - 1; $lvl >= 0; $lvl--) {
            if ($li_open[$lvl]) { $out .= "</li>\n"; $li_open[$lvl] = false; }
            $out .= '</' . $list_stack[$lvl] . ">\n";
        }
        $list_stack = array(); $li_open = array();
    }

    function md_inline($text, $options) {
        // Inline code
        if (!function_exists('md_cb_inline_code_backticks')) {
            function md_cb_inline_code_backticks($m) { return '<code>' . wiki_escape_html($m[1]) . '</code>'; }
        }
        $text = preg_replace_callback('/`([^`\n]+)`/', 'md_cb_inline_code_backticks', $text);

        // Images: ![alt](url)
        if (!function_exists('md_cb_image')) {
            function md_cb_image($m) {
                $alt = trim($m[1]); $url = wiki_sanitize_url($m[2]);
                if ($url === '') return wiki_escape_html($m[0]);
                return '<img src="' . wiki_attr($url) . '" alt="' . wiki_attr($alt) . '" />';
            }
        }
        $text = preg_replace_callback('/!\[([^\]]*)\]\(([^\)\s]+)\)/', 'md_cb_image', $text);

        // Bold/Italic: **, * (non-greedy best-effort)
        $text = preg_replace('/\*\*([^*]+)\*\*/s', '<strong>$1</strong>', $text);
        $text = preg_replace('/\*([^*]+)\*/s', '<em>$1</em>', $text);

        // Internal wiki-style links [[Page]] or [[Label|URL]] or [[Page|Label]]
        if (!function_exists('wiki_build_internal_href')) {
            function wiki_build_internal_href($page) {
                $base = isset($GLOBALS['__wiki_internal_base']) ? $GLOBALS['__wiki_internal_base'] : 'wiki.php';
                $param = isset($GLOBALS['__wiki_internal_param']) ? $GLOBALS['__wiki_internal_param'] : 'title';
                $href = $base; $sep = (strpos($href, '?') !== false) ? '&' : '?';
                $href .= $sep . $param . '=' . rawurlencode(trim($page));
                return $href;
            }
        }
        if (!function_exists('md_cb_internal_link')) {
            function md_cb_internal_link($m) {
                if (!isset($GLOBALS['__wiki_internal_on']) || !$GLOBALS['__wiki_internal_on']) { return wiki_escape_html($m[0]); }
                $a = trim($m[1]); $b = isset($m[2]) ? trim($m[2]) : '';
                // If b is empty: [[Page]] -> internal link
                if ($b === '') {
                    $href = wiki_build_internal_href($a);
                    return '<a href="' . wiki_attr($href) . '">' . wiki_escape_html($a) . '</a>';
                }
                // If one looks like URL, treat accordingly
                if (preg_match('/^https?:\/\//i', $a)) { $url = wiki_sanitize_url($a); $label = $b; }
                else if (preg_match('/^https?:\/\//i', $b)) { $url = wiki_sanitize_url($b); $label = $a; }
                else { $href = wiki_build_internal_href($a); return '<a href="' . wiki_attr($href) . '">' . wiki_escape_html($b) . '</a>'; }
                if ($url === '') return wiki_escape_html($m[0]);
                $attrs = ' href="' . wiki_attr($url) . '"';
                $rel_nofollow = !isset($GLOBALS['__wiki_rel_nofollow']) || $GLOBALS['__wiki_rel_nofollow'];
                if ($rel_nofollow) { $attrs .= ' rel="nofollow"'; }
                return '<a' . $attrs . '>' . wiki_escape_html($label) . '</a>';
            }
        }
        $GLOBALS['__wiki_internal_on'] = isset($options['internal_links']) ? (bool)$options['internal_links'] : true;
        $GLOBALS['__wiki_internal_base'] = isset($options['internal_base']) ? $options['internal_base'] : 'wiki.php';
        $GLOBALS['__wiki_internal_param'] = isset($options['internal_param']) ? $options['internal_param'] : 'title';
        $GLOBALS['__wiki_rel_nofollow'] = isset($options['rel_nofollow']) ? (bool)$options['rel_nofollow'] : true;
        $text = preg_replace_callback('/\[\[([^\]|]+)(?:\|([^\]]+))?\]\]/', 'md_cb_internal_link', $text);

        // Auto-link URLs (optional)
        if (isset($options['auto_link']) && $options['auto_link']) {
            if (!function_exists('md_cb_autolink')) {
                function md_cb_autolink($m) {
                    $lead = isset($m[1]) ? $m[1] : '';
                    $url = wiki_sanitize_url($m[2]); if ($url === '') return $m[0];
                    $attrs = ' href="' . wiki_attr($url) . '"';
                    $rel_nofollow = !isset($GLOBALS['__wiki_rel_nofollow']) || $GLOBALS['__wiki_rel_nofollow'];
                    if ($rel_nofollow) { $attrs .= ' rel="nofollow"'; }
                    return $lead . '<a' . $attrs . '>' . wiki_escape_html($url) . '</a>';
                }
            }
            $text = preg_replace_callback('/(^|[^=\"\'])(https?:\/\/[\w\-\.\~\/%\?#@!$&\'"()*+,;=:\[\]]+)/', 'md_cb_autolink', $text);
        }

        // Escape remaining text outside tags
        $parts = preg_split('/(<[^>]+>)/', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
        $rebuilt = '';
        for ($i=0; $i<count($parts); $i++) {
            $part = $parts[$i]; if ($part === '') continue;
            if ($part{0} === '<') { $rebuilt .= $part; }
            else { $rebuilt .= wiki_escape_html($part); }
        }
        return $rebuilt;
    }
}

// --- Markdown table helpers ---
if (!function_exists('md_maybe_table_row')) {
    function md_maybe_table_row($line) {
        // A simple heuristic: contains at least one '|' and not only spaces/hyphens/colons
        if (strpos($line, '|') === false) return false;
        // Exclude code fences
        if (trim($line) === '```') return false;
        return true;
    }
}
if (!function_exists('md_is_table_delim_line')) {
    function md_is_table_delim_line($line, &$aligns) {
        $aligns = array();
        if ($line === null) return false;
        $t = trim($line);
        if ($t === '') return false;
        // Remove optional leading/trailing '|'
        if ($t{0} === '|') { $t = substr($t, 1); }
        if ($t !== '' && substr($t, -1) === '|') { $t = substr($t, 0, -1); }
        $parts = explode('|', $t);
        if (!count($parts)) return false;
        $ok_any = false;
        for ($i=0; $i<count($parts); $i++) {
            $p = trim($parts[$i]);
            if ($p === '') { $aligns[] = ''; continue; }
            // Valid if contains at least 3 hyphens, optional leading/trailing colon for alignment
            $left = (strlen($p) && $p{0} === ':');
            $right = (strlen($p) && substr($p, -1) === ':');
            $core = $p;
            if ($left) { $core = substr($core, 1); }
            if ($right && $core !== '') { $core = substr($core, 0, -1); }
            $core = trim($core);
            // core must be at least 3 hyphens
            if (!preg_match('/^-{3,}$/', $core)) { return false; }
            $ok_any = true;
            $align = '';
            if ($left && $right) { $align = 'c'; }
            else if ($right) { $align = 'r'; }
            else if ($left) { $align = 'l'; }
            $aligns[] = $align;
        }
        return $ok_any;
    }
}
if (!function_exists('md_table_cells')) {
    function md_table_cells($line) {
        $t = trim($line);
        if ($t === '') return array();
        if ($t{0} === '|') { $t = substr($t, 1); }
        if ($t !== '' && substr($t, -1) === '|') { $t = substr($t, 0, -1); }
        $parts = explode('|', $t);
        for ($i=0; $i<count($parts); $i++) { $parts[$i] = trim($parts[$i]); }
        return $parts;
    }
}
if (!function_exists('md_align_style')) {
    function md_align_style($a) {
        if ($a === 'l') return 'text-align:left';
        if ($a === 'r') return 'text-align:right';
        if ($a === 'c') return 'text-align:center';
        return '';
    }
}

if (!function_exists('wiki_render')) {
    function wiki_render($text, $options = array()) {
        $renderer = isset($options['renderer']) ? $options['renderer'] : (defined('WIKI_RENDERER') ? constant('WIKI_RENDERER') : 'wiki');
        if ($renderer === 'markdown_wiki') { return md_parse($text, $options); }
        return wiki_parse($text, $options);
    }
}

?>
