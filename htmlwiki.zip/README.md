PHP4 Minimal Wiki Parser (Cafe24-friendly)

Overview
- Minimal wiki-to-HTML parser implemented in plain PHP 4–compatible style.
- Safe subset: headings, emphasis, inline code, links, images, lists, blockquotes, code blocks, horizontal rules, and paragraphs.
- Designed for legacy shared hosts (e.g., Cafe24 PHP 4.x) without external dependencies.

Engine
- Tiny file-based wiki engine is included for PHP4.
- Routes: view, edit, save, all pages, search, history, rename, delete.
- Pages are stored as UTF-8 text under `data/pages/` with percent-encoded filenames.
- Internal links like `[[Page]]` or `[[Page|Label]]` route to `public/wiki.php`.
 - Edit/Delete protection: a simple global password is required for saving and deleting pages.
 - Seed pages: `FrontPage` and `SyntaxGuide` are auto-created on first visit if missing.

Renderer Modes
- Default: `wiki` (MediaWiki-like subset defined below).
- Optional: `markdown_wiki` (Markdown blocks + wiki-style links `[[...]]`).
- Switch by editing `src/wiki_engine.php` and setting:
  - `define('WIKI_RENDERER', 'markdown_wiki');`
  - FrontPage/SyntaxGuide seeds adapt to the selected mode.

Why
- The OCaml project html_of_wiki is not directly usable on PHP-only hosting. This parser provides a pragmatic subset that works on very old PHP stacks.

Supported Syntax
- Headings: `= H1 =` … `====== H6 ======`
- Emphasis: `''italic''`, `'''bold'''`, `'''''bold italic'''''`
- Inline code: `{{{code}}}` or `` `code` ``
- Code blocks: line `{{{` … line `}}}` (or triple backticks ``` … ```)
- Links:
  - `[[https://example.com|Label]]` or `[[Label|https://example.com]]`
  - `[https://example.com Label]`
  - Auto-link of bare URLs is optional (off by default)
  - Internal links: `[[Page]]` or `[[Page|Label]]` (engine integration)
- Images: `[[Image:https://example.com/pic.png|Alt text]]` (also `File:` or `img:`)
- Lists: `*` unordered, `#` ordered; nest by repeating markers (e.g., `**`)
- Blockquote: lines starting with `>` (consecutive lines are grouped)
- Horizontal rule: a line with 4+ hyphens (`----`)
- Paragraphs: separated by blank lines
  - Single newline inside a paragraph creates a `<br />` (hard-wrap). Set `hard_wrap => false` to disable.

Markdown Wiki mode
- Blocks: Markdown headings `# .. ######`, blockquotes `>`, lists `-`/`+`/`*` and `1.`, fenced code blocks ``` ```, tables.
- Inline: `*italic*`, `**bold**`, inline code `` `code` ``; images `![alt](url)`.
- Links: Use wiki-style `[[Page]]`, `[[Page|Label]]`, or `[[Label|https://..]]` (external) — Markdown `[text](url)` is not used for internal links.
  - Tables: header row, delimiter row (---, :---, ---:, :---: for align), then data rows. Example:
    
    | Col A | Col B |
    | :--- | ---: |
    | left | right |

Tables (MediaWiki-style subset)
- Start: `{|` on its own line; End: `|}` on its own line.
- Caption: `|+ Caption text`
- Header row: `! H1 !! H2 !! H3`
- Data row: `| C1 || C2 || C3`
- Optional row separator `|-` between rows is supported (attributes ignored).
- Cell attributes like `| style=... | Text` are ignored for safety; text after the first `|` is used.

Example:
```
{|
! Header A !! Header B !! Header C
|-
| Cell A1 || Cell B1 || Cell C1
|-
| Cell A2 || Cell B2 || Cell C2
|}
```

Security Notes
- All non-markup text is HTML-escaped.
- Links/images are restricted to `http`/`https` URLs. Others are rejected.
- Links include `rel="nofollow"` by default. Set `rel_nofollow => false` to disable.
 - Editing/Deleting requires the fixed password (default: `qkrqudtn1!`). Change `WIKI_EDIT_PASSWORD` in `src/wiki_engine.php` for your deployment.

 Project Layout
- `src/wiki_parser.php`: Parser functions.
- `src/wiki_engine.php`: Engine helpers (file storage, history, search).
- `public/index.php`: Redirects to `public/wiki.php?a=front` (FrontPage via router).
- `public/syntax.php`: Redirects to `public/wiki.php?a=view&title=SyntaxGuide`.
- `public/wiki.php`: Wiki engine router (view/edit/save/search/history).

Theming
- Light/Dark theme toggle is available in FrontPage, Syntax guide, and Wiki UI.
- Preference is saved to `localStorage` and applied site-wide.

Requirements
- PHP 4.3+ (tested for compatibility in syntax; uses `preg_*` and `htmlspecialchars`).
- No database, no extensions required beyond PCRE (standard on PHP 4.x).

 Quick Start
1. Upload the repository to your hosting (e.g., `public/` under `public_html/`).
2. Ensure `data/` is writable by the webserver (e.g., `chmod -R 775 data/`).
 3. Visit `public/index.php` (redirects to FrontPage) or `public/wiki.php` for direct routes.
4. Open `wiki.php?title=Home`, click Edit to create the page.
5. Use Rename to change a page title (optionally update links in other pages, leave a redirect stub, and set per-request update limit).

Embedding in Existing PHP 4 Project
```php
require_once('/path/to/src/wiki_parser.php');
$html = wiki_parse($wiki_text, array(
  'auto_link' => false,     // set true to auto-link bare URLs
  'rel_nofollow' => true,   // link rel attribute
  'hard_wrap' => true,      // single newline -> <br />
));
echo $html;
```

Limitations
- This is a minimal subset, not a full MediaWiki/Text_Wiki implementation.
- Nested lists with rapid type changes (#/* mix) are supported best-effort.
- Tables are supported without attributes; templates/macros are not implemented.
 - Link updates during rename handle the common forms `[[Old]]` and `[[Old|Label]]` and may not cover unusual whitespace/newline cases.
 - Link updates skip code/pre areas (block `{{{ ... }}}`, ``` ... ```, inline `{{{...}}}`, `` `...` ``).
 - For many pages, use the per-request update limit to avoid timeouts; repeat the rename step to process more pages until complete.

Notes on PEAR Text_Wiki Option (Alternative Approach)
- If you must use a historical parser like PEAR `Text_Wiki` 1.x, vendor its PHP 4–compatible files under `vendor/` and wrap its output. Network is disabled here, so this repo implements the minimal custom parser instead.

License
- Provided as-is for legacy hosting compatibility. Use at your own discretion.
